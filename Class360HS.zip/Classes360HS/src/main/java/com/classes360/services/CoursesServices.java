package com.classes360.services;

import com.classes360.beans.Courses;
import com.classes360.repositories.CoursesRepo;

public class CoursesServices implements CoursesRepo {

	public int saveCourse(Courses courses) {
		// TODO Auto-generated method stub
		return 0;
	}

}
