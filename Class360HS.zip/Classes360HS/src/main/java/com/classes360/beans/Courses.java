package com.classes360.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Courses implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer courseId;

	@Column
	private String coursesName;

	@Column
	private String courseDuration;

	@Column
	private String courseTrainer;
	
	@Column
	private String courseFees;

	public Courses() {
		// TODO Auto-generated constructor stub
	}

	public Courses(Integer courseId, String coursesName, String courseDuration, String courseTrainer,
			String courseFees) {
		super();
		this.courseId = courseId;
		this.coursesName = coursesName;
		this.courseDuration = courseDuration;
		this.courseTrainer = courseTrainer;
		this.courseFees = courseFees;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public String getCoursesName() {
		return coursesName;
	}

	public void setCoursesName(String coursesName) {
		this.coursesName = coursesName;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public String getCourseTrainer() {
		return courseTrainer;
	}

	public void setCourseTrainer(String courseTrainer) {
		this.courseTrainer = courseTrainer;
	}

	public String getCourseFees() {
		return courseFees;
	}

	public void setCourseFees(String courseFees) {
		this.courseFees = courseFees;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Courses [courseId=" + courseId + ", coursesName=" + coursesName + ", courseDuration=" + courseDuration
				+ ", courseTrainer=" + courseTrainer + ", courseFees=" + courseFees + "]";
	}
	
	
	
}