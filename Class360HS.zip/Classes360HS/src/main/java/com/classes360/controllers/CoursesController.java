package com.classes360.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.classes360.beans.Courses;


@WebServlet(value = "/Course")
public class CoursesController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;

	public final static Logger logger = Logger.getLogger(CoursesController.class);
	// This Method Is Used To Create The Hibernate's SessionFactory Object
	private static SessionFactory buildSessionFactory() {
		Configuration configObj = new Configuration();
		configObj.configure("hibernate.cfg.xml");
		ServiceRegistry serviceRegistryObj = new StandardServiceRegistryBuilder().applySettings(configObj.getProperties()).build(); 
		sessionFactoryObj = configObj.buildSessionFactory(serviceRegistryObj);
		return sessionFactoryObj;
	}
	
	// Method 1: This Method Used To Create A New Student Record In The Database Table
		public static void createRecord() {
			int count = 0;
			Courses course = null;
			try {
				sessionObj = buildSessionFactory().openSession();
				sessionObj.beginTransaction();

				for(int j = 101; j <= 105; j++) {
					count = count + 1;
					course = new Courses();
					
					course.setCourseId(j);
					course.setCoursesName("JAVA");
					course.setCourseDuration("2 Month");
					course.setCourseTrainer("Ritesh Sir");
					course.setCourseFees("30000");
					sessionObj.save(course);
				}
				sessionObj.getTransaction().commit();
				logger.info("\nSuccessfully Created '" + count + "' Records In The Database!\n");
			} catch(Exception sqlException) {
				if(null != sessionObj.getTransaction()) {
					logger.info("\n.......Transaction Is Being Rolled Back.......\n");
					sessionObj.getTransaction().rollback();
				}
				sqlException.printStackTrace();
			} finally {
				if(sessionObj != null) {
					sessionObj.close();
				}
			}
		}
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Course Controller Called from UI");
		System.out.println(request.getParameter("coursesName"));
		System.out.println(request.getParameter("courseDuration"));
		System.out.println(request.getParameter("courseTrainer"));
		System.out.println(request.getParameter("courseFees"));
		
		createRecord();
		
		// Hibernate code for insert data in db
		
		
		
		
		
		
		
		RequestDispatcher rd=request.getRequestDispatcher("adminCourses.jsp");
		rd.forward(request, response);
	}

}