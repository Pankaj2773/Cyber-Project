package com.classes360.repositories;

import com.classes360.beans.Courses;

public interface CoursesRepo {
	
	public int saveCourse(Courses courses);

}
